<?php
/**
 * Plugin Name:       TLN Conference Calendar
 * Plugin URI:        https://thelocalnational.com/conferences/
 * Description:       The Local National's D.C. and Baltimore Conference Calendars. Add [tln_conferences] to any page for upcoming conferences with topic filters, calendar subscriptions and add-to-calendar links. Data comes from the public calendar feed and refreshes hourly.
 * Version:           1.3.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            The Local National
 * License:           GPL-2.0-or-later
 * Text Domain:       tln-conference-calendar
 *
 * Shortcode options:
 *   [tln_conferences]                                   full calendar with subscribe panel and topic filters
 *   [tln_conferences theme="housing"]                   one topic (any calendar slug, e.g. transit, tln-picks, major)
 *   [tln_conferences region="baltimore"]                fixed Baltimore calendar without the city switch
 *   [tln_conferences limit="5" compact="yes" subscribe="no" filters="no"]   short list for a sidebar or the homepage
 *   [tln_conferences wall="no"]                         full D.C. calendar without the wall calendar beside it
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TLN_CC_VERSION', '1.3.0' );
define( 'TLN_CC_DEFAULT_SOURCE', 'https://calendar.thelocalnational.com/api/events.json' );
define( 'TLN_CC_PAGE_STATUS', 'draft' );
define( 'TLN_CC_FILE', __FILE__ );

/* ------------------------------------------------------------------ data */

function tln_cc_source_url() {
	$url = (string) get_option( 'tln_cc_source_url', '' );
	if ( '' === $url ) {
		$url = TLN_CC_DEFAULT_SOURCE;
	}
	return apply_filters( 'tln_cc_source_url', $url );
}

/** Only the two supported cities can select a source or cache namespace. */
function tln_cc_region( $fixed = '' ) {
	if ( is_string( $fixed ) && in_array( $fixed, array( 'dc', 'baltimore' ), true ) ) {
		return $fixed;
	}
	$value = isset( $_GET['region'] ) && is_string( $_GET['region'] ) ? sanitize_key( wp_unslash( $_GET['region'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return 'baltimore' === $value ? 'baltimore' : 'dc';
}

function tln_cc_cache_key( $key, $region = 'dc' ) {
	return $key . ( 'baltimore' === $region ? '_baltimore' : '' );
}

/** The optional Baltimore source is a sibling of the configured D.C. JSON. */
function tln_cc_region_source_url( $region = 'dc' ) {
	$source = tln_cc_source_url();
	if ( 'baltimore' !== $region ) {
		return $source;
	}
	$url  = preg_replace( '/[?#].*$/', '', $source );
	$path = (string) parse_url( $url, PHP_URL_PATH );
	$dir  = '' === $path || '/' === substr( $path, -1 ) ? $path : substr( $path, 0, strrpos( $path, '/' ) + 1 );
	$root = '' === $path ? $url : substr( $url, 0, strlen( $url ) - strlen( $path ) );
	return $root . '/' . trim( $dir, '/' ) . ( '' === trim( $dir, '/' ) ? '' : '/' ) . 'baltimore.json';
}

/** City links use the current permalink, not arbitrary request parameters. */
function tln_cc_region_page_url( $region = 'dc', $url = '' ) {
	if ( '' === $url ) {
		$url = get_permalink();
	}
	$url = remove_query_arg( 'region', $url );
	return 'baltimore' === $region ? add_query_arg( 'region', 'baltimore', $url ) : $url;
}

function tln_cc_render_regions( $region ) {
	return '<nav class="tlncc-regions" aria-label="' . esc_attr__( 'Choose a city', 'tln-conference-calendar' ) . '">'
		. '<a class="tlncc-region" href="' . esc_url( tln_cc_region_page_url() ) . '"' . ( 'dc' === $region ? ' aria-current="page"' : '' ) . '>D.C.</a>'
		. '<a class="tlncc-region" href="' . esc_url( tln_cc_region_page_url( 'baltimore' ) ) . '"' . ( 'baltimore' === $region ? ' aria-current="page"' : '' ) . '>Baltimore</a></nav>';
}

/** Discovery follows the first calendar shortcode, including a fixed region. */
function tln_cc_page_region() {
	$post = get_post();
	if ( $post && preg_match_all( '/' . get_shortcode_regex( array( 'tln_conferences' ) ) . '/s', $post->post_content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $match ) {
			if ( '[' === $match[1] && ']' === $match[6] ) {
				continue;
			}
			$atts = shortcode_parse_atts( $match[3] );
			return tln_cc_region( is_array( $atts ) && isset( $atts['region'] ) ? $atts['region'] : '' );
		}
	}
	return tln_cc_region();
}

/** Fetch the public feed. Returns the decoded array, or null on any failure. */
function tln_cc_fetch( $region = 'dc' ) {
	$resp = wp_remote_get(
		tln_cc_region_source_url( $region ),
		array(
			'timeout' => 10,
			'headers' => array( 'Accept' => 'application/json' ),
		)
	);
	if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
		update_option( tln_cc_cache_key( 'tln_cc_last_error', $region ), is_wp_error( $resp ) ? $resp->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $resp ), false );
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( ! is_array( $data ) || ! isset( $data['events'], $data['calendars'] ) || ! is_array( $data['events'] ) || ! is_array( $data['calendars'] ) || ( isset( $data['region'] ) && $region !== $data['region'] ) ) {
		update_option( tln_cc_cache_key( 'tln_cc_last_error', $region ), 'Unexpected response format', false );
		return null;
	}
	set_transient( tln_cc_cache_key( 'tln_cc_data', $region ), $data, 2 * HOUR_IN_SECONDS );
	update_option( tln_cc_cache_key( 'tln_cc_last_good', $region ), $data, false );
	update_option( tln_cc_cache_key( 'tln_cc_last_fetch', $region ), time(), false );
	delete_option( tln_cc_cache_key( 'tln_cc_last_error', $region ) );
	return $data;
}

/** Cached data; falls back to the last good copy if the feed is unreachable. */
function tln_cc_data( $region = 'dc' ) {
	$data = get_transient( tln_cc_cache_key( 'tln_cc_data', $region ) );
	if ( is_array( $data ) ) {
		return $data;
	}
	$data = tln_cc_fetch( $region );
	if ( is_array( $data ) ) {
		return $data;
	}
	$stale = get_option( tln_cc_cache_key( 'tln_cc_last_good', $region ) );
	if ( is_array( $stale ) ) {
		set_transient( tln_cc_cache_key( 'tln_cc_data', $region ), $stale, 10 * MINUTE_IN_SECONDS );
		return $stale;
	}
	return null;
}

function tln_cc_today() {
	$now = new DateTime( 'now', new DateTimeZone( 'America/New_York' ) );
	return $now->format( 'Y-m-d' );
}

function tln_cc_str( $arr, $key ) {
	return ( is_array( $arr ) && isset( $arr[ $key ] ) && is_scalar( $arr[ $key ] ) ) ? (string) $arr[ $key ] : '';
}

function tln_cc_yes( $value ) {
	return in_array( strtolower( (string) $value ), array( 'yes', 'true', '1', 'on' ), true );
}

/* ------------------------------------------------------------------ assets */

add_action(
	'init',
	function () {
		$dir = plugin_dir_path( TLN_CC_FILE );
		$css = $dir . 'assets/tlncc.css';
		$js  = $dir . 'assets/tlncc.js';
		wp_register_style( 'tln-cc', plugins_url( 'assets/tlncc.css', TLN_CC_FILE ), array(), file_exists( $css ) ? (string) filemtime( $css ) : TLN_CC_VERSION );
		wp_register_script( 'tln-cc', plugins_url( 'assets/tlncc.js', TLN_CC_FILE ), array(), file_exists( $js ) ? (string) filemtime( $js ) : TLN_CC_VERSION, true );
		add_shortcode( 'tln_conferences', 'tln_cc_shortcode' );
	}
);

function tln_cc_page_has_shortcode() {
	if ( ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( $post->post_content, 'tln_conferences' );
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( tln_cc_page_has_shortcode() ) {
			wp_enqueue_style( 'tln-cc' );
		}
	}
);

/* Let browsers and calendar apps discover the feed on pages that show the calendar. */
add_action(
	'wp_head',
	function () {
		if ( ! tln_cc_page_has_shortcode() ) {
			return;
		}
		$data = tln_cc_data( tln_cc_page_region() );
		if ( ! $data ) {
			return;
		}
		foreach ( $data['calendars'] as $calendar ) {
			if ( 'all' === tln_cc_str( $calendar, 'slug' ) && ! empty( $calendar['links']['ics'] ) ) {
				printf(
					'<link rel="alternate" type="text/calendar" title="%s" href="%s" />' . "\n",
					esc_attr( tln_cc_str( $calendar, 'feed_name' ) ),
					esc_url( $calendar['links']['ics'] )
				);
				break;
			}
		}
	}
);

/* ------------------------------------------------------------------ rendering */

function tln_cc_shortcode( $atts ) {
	$a = shortcode_atts(
		array(
			'theme'     => 'all',
			'limit'     => 0,
			'subscribe' => 'yes',
			'filters'   => 'yes',
				'compact'   => 'no',
				'title'     => '',
				'region'    => '',
				'wall'      => 'yes',
			),
		$atts,
		'tln_conferences'
	);
	wp_enqueue_style( 'tln-cc' );
	wp_enqueue_script( 'tln-cc' );

	$region  = tln_cc_region( $a['region'] );
	$pinned  = is_string( $a['region'] ) && in_array( $a['region'], array( 'dc', 'baltimore' ), true );
	$compact = tln_cc_yes( $a['compact'] );
	$nav     = ! $compact && ! $pinned ? tln_cc_render_regions( $region ) : '';
	$data    = tln_cc_data( $region );
	if ( ! $data ) {
		if ( 'baltimore' === $region ) {
			return '<div class="tlncc">' . $nav . '<p class="tlncc-empty">' . esc_html__( 'The Baltimore calendar is not available right now.', 'tln-conference-calendar' ) . ' <a href="' . esc_url( tln_cc_region_page_url() ) . '">' . esc_html__( 'See the D.C. calendar', 'tln-conference-calendar' ) . '</a></p></div>';
		}
		return '<div class="tlncc">' . $nav . '<p class="tlncc-empty">' . esc_html__( 'The conference calendar is updating. Please check back shortly.', 'tln-conference-calendar' ) . '</p></div>';
	}

	$today = tln_cc_today();
	$cals  = array();
	foreach ( $data['calendars'] as $c ) {
		if ( is_array( $c ) && isset( $c['slug'] ) ) {
			$cals[ (string) $c['slug'] ] = $c;
		}
	}
	$theme = sanitize_key( $a['theme'] );
	if ( ! isset( $cals[ $theme ] ) ) {
		$theme = 'all';
	}
	$limit     = absint( $a['limit'] );
	$compact   = tln_cc_yes( $a['compact'] );
	$subscribe = tln_cc_yes( $a['subscribe'] );
	$filters   = tln_cc_yes( $a['filters'] ) && 'all' === $theme && ! $compact;

	$upcoming = array();
	foreach ( $data['events'] as $e ) {
		if ( ! is_array( $e ) || tln_cc_str( $e, 'end_date' ) < $today || '' === tln_cc_str( $e, 'id' ) ) {
			continue;
		}
		$e['segments'] = ( isset( $e['segments'] ) && is_array( $e['segments'] ) ) ? array_map( 'strval', $e['segments'] ) : array();
		$upcoming[]    = $e;
	}
	$counts = array_fill_keys( array_keys( $cals ), 0 );
	foreach ( $upcoming as $e ) {
		$counts['all'] = isset( $counts['all'] ) ? $counts['all'] + 1 : 1;
		foreach ( $e['segments'] as $s ) {
			if ( isset( $counts[ $s ] ) ) {
				$counts[ $s ]++;
			}
		}
	}
	$events = array();
	foreach ( $upcoming as $e ) {
		if ( 'all' === $theme || in_array( $theme, $e['segments'], true ) ) {
			$events[] = $e;
		}
	}
	if ( $limit > 0 ) {
		$events = array_slice( $events, 0, $limit );
	}

	/* The wall calendar only appears beside the full D.C. calendar: every dot then has a matching entry in the list. */
	$wall = '';
	if ( ! $compact && 'dc' === $region && 'all' === $theme && 0 === $limit && tln_cc_yes( $a['wall'] ) ) {
		$wall = tln_cc_render_wall( $upcoming, $today );
	}

	$out  = '<div class="tlncc' . ( $compact ? ' is-compact' : '' ) . ( '' !== $wall ? ' has-wall' : '' ) . '" data-tlncc data-default-seg="' . esc_attr( $filters ? 'all' : $theme ) . '">';
	if ( '' !== $wall ) {
		$out .= '<div class="tlncc-layout">' . $wall . '<div class="tlncc-main">';
	}
	$out .= $nav;
	if ( ! $compact && '' !== tln_cc_str( $data, 'region_note' ) ) {
		$out .= '<p class="tlncc-region-note">' . esc_html( tln_cc_str( $data, 'region_note' ) ) . '</p>';
	}
	if ( '' !== $a['title'] ) {
		$out .= '<h2 class="tlncc-h2">' . esc_html( $a['title'] ) . '</h2>';
	}
	if ( $subscribe ) {
		$out .= tln_cc_render_subscribe( $cals, $counts, $theme );
	}
	if ( $filters ) {
		$out .= tln_cc_render_tools( $cals, $counts );
	}
	$out .= '<div class="tlncc-list">';
	if ( ! $events ) {
		$out .= '<p class="tlncc-empty">' . esc_html__( 'No upcoming events are listed right now. Subscribe and new ones will appear as they are added.', 'tln-conference-calendar' ) . '</p>';
	}
	$group = null;
	foreach ( $events as $e ) {
		$label = tln_cc_group_label( $e, $today );
		if ( $label !== $group ) {
			if ( null !== $group ) {
				$out .= '</section>';
			}
			$out  .= '<section class="tlncc-month" data-tlncc-group><h3 class="tlncc-mh">' . esc_html( $label ) . '</h3>';
			$group = $label;
		}
		$out .= tln_cc_render_event( $e, $compact );
	}
	if ( null !== $group ) {
		$out .= '</section>';
	}
	$out .= '</div>';
	$out .= '<p class="tlncc-empty" data-tlncc-empty hidden>' . esc_html__( 'No events match. Try another topic or clear the search.', 'tln-conference-calendar' ) . '</p>';
	$out .= tln_cc_render_footer( $data, $theme, $compact, $region );
	$out .= tln_cc_render_schema( $events );
	if ( '' !== $wall ) {
		$out .= '</div></div>';
	}
	$out .= '</div>';
	return $out;
}

function tln_cc_group_label( $e, $today ) {
	$start = tln_cc_str( $e, 'start_date' );
	if ( $start < $today ) {
		return __( 'Under way', 'tln-conference-calendar' );
	}
	$d = DateTime::createFromFormat( '!Y-m-d', $start, new DateTimeZone( 'America/New_York' ) );
	return $d ? $d->format( 'F Y' ) : '';
}

function tln_cc_render_subscribe( $cals, $counts, $selected ) {
	if ( ! isset( $cals[ $selected ]['links'] ) ) {
		return '';
	}
	$opts  = '';
	$feeds = '';
	foreach ( $cals as $slug => $c ) {
		$l = isset( $c['links'] ) && is_array( $c['links'] ) ? $c['links'] : array();
		$n = isset( $counts[ $slug ] ) ? (int) $counts[ $slug ] : 0;
		/* translators: 1: calendar name, 2: number of upcoming events */
		$opts  .= sprintf(
			'<option value="%1$s" data-webcal="%2$s" data-google="%3$s" data-outlook="%4$s" data-office="%5$s" data-ics="%6$s"%7$s>%8$s</option>',
			esc_attr( $slug ),
			esc_url( tln_cc_str( $l, 'webcal' ) ),
			esc_url( tln_cc_str( $l, 'google' ) ),
			esc_url( tln_cc_str( $l, 'outlook' ) ),
			esc_url( tln_cc_str( $l, 'office' ) ),
			esc_url( tln_cc_str( $l, 'ics' ) ),
			selected( $slug, $selected, false ),
			esc_html( sprintf( '%s (%d upcoming)', tln_cc_str( $c, 'name' ), $n ) )
		);
		$feeds .= sprintf(
			'<li><strong>%1$s</strong><span>%2$s</span><a href="%3$s">Apple</a><a href="%4$s" target="_blank" rel="noopener">Google</a><a href="%5$s" target="_blank" rel="noopener">Outlook</a><a href="%6$s">.ics link</a></li>',
			esc_html( tln_cc_str( $c, 'name' ) ),
			esc_html( sprintf( '%d upcoming', $n ) ),
			esc_url( tln_cc_str( $l, 'webcal' ) ),
			esc_url( tln_cc_str( $l, 'google' ) ),
			esc_url( tln_cc_str( $l, 'outlook' ) ),
			esc_url( tln_cc_str( $l, 'ics' ) )
		);
	}
	$l   = $cals[ $selected ]['links'];
	$uid = 'tlncc-pick-' . wp_unique_id();
	$out  = '<section class="tlncc-sub" id="subscribe">';
	$out .= '<h2 class="tlncc-h2">' . esc_html__( 'Put it on your calendar', 'tln-conference-calendar' ) . '</h2>';
	$out .= '<p class="tlncc-note">' . esc_html__( 'Subscribe once and new events show up on their own. Take everything, or only the topics you follow.', 'tln-conference-calendar' ) . '</p>';
	$out .= '<div class="tlncc-sub-row"><label class="tlncc-label" for="' . esc_attr( $uid ) . '">' . esc_html__( 'Calendar', 'tln-conference-calendar' ) . '</label>';
	$out .= '<select class="tlncc-select" id="' . esc_attr( $uid ) . '" data-tlncc-sub>' . $opts . '</select></div>';
	$out .= '<div class="tlncc-sub-buttons">';
	$out .= '<a class="tlncc-btn" data-sub-k="webcal" href="' . esc_url( tln_cc_str( $l, 'webcal' ) ) . '">Apple Calendar</a>';
	$out .= '<a class="tlncc-btn" data-sub-k="google" href="' . esc_url( tln_cc_str( $l, 'google' ) ) . '" target="_blank" rel="noopener">Google Calendar</a>';
	$out .= '<a class="tlncc-btn" data-sub-k="outlook" href="' . esc_url( tln_cc_str( $l, 'outlook' ) ) . '" target="_blank" rel="noopener">Outlook.com</a>';
	$out .= '<a class="tlncc-btn is-ghost" data-sub-k="office" href="' . esc_url( tln_cc_str( $l, 'office' ) ) . '" target="_blank" rel="noopener">Outlook for work</a>';
	$out .= '<button type="button" class="tlncc-btn is-ghost tlncc-copy" data-sub-k="ics" data-url="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '">' . esc_html__( 'Copy feed link', 'tln-conference-calendar' ) . '</button>';
	$out .= '</div>';
	$out .= '<p class="tlncc-hint">' . esc_html__( 'On iPhone, iPad or Mac, tap Apple Calendar. Google subscriptions are added on the web and then sync to your phone. Any other calendar app can use the copied feed link.', 'tln-conference-calendar' ) . '</p>';
	/* translators: %d: number of calendar feeds */
	$out .= '<details class="tlncc-feeds"><summary>' . esc_html( sprintf( __( 'All %d calendar feeds', 'tln-conference-calendar' ), count( $cals ) ) ) . '</summary><ul>' . $feeds . '</ul></details>';
	$out .= '</section>';
	return $out;
}

function tln_cc_render_tools( $cals, $counts ) {
	$uid   = 'tlncc-q-' . wp_unique_id();
	$chips = sprintf(
		'<button type="button" class="tlncc-chip" data-seg="all" data-name="all topics" aria-pressed="true">%s<span>%d</span></button>',
		esc_html__( 'All', 'tln-conference-calendar' ),
		isset( $counts['all'] ) ? (int) $counts['all'] : 0
	);
	foreach ( $cals as $slug => $c ) {
		if ( 'all' === $slug || empty( $counts[ $slug ] ) ) {
			continue;
		}
		$chips .= sprintf(
			'<button type="button" class="tlncc-chip" data-seg="%1$s" data-name="%2$s" aria-pressed="false">%2$s<span>%3$d</span></button>',
			esc_attr( $slug ),
			esc_html( tln_cc_str( $c, 'name' ) ),
			(int) $counts[ $slug ]
		);
	}
	return '<div class="tlncc-tools"><div class="tlncc-filters" role="toolbar" aria-label="' . esc_attr__( 'Filter by topic', 'tln-conference-calendar' ) . '">' . $chips . '</div>'
		. '<div class="tlncc-search"><label class="tlncc-vh" for="' . esc_attr( $uid ) . '">' . esc_html__( 'Search events', 'tln-conference-calendar' ) . '</label>'
		. '<input id="' . esc_attr( $uid ) . '" type="search" placeholder="' . esc_attr__( 'Search events, organizers or venues', 'tln-conference-calendar' ) . '" data-tlncc-q autocomplete="off"></div></div>'
		. '<p class="tlncc-status" data-tlncc-status aria-live="polite"></p>';
}

function tln_cc_render_event( $e, $compact ) {
	$l     = ( isset( $e['links'] ) && is_array( $e['links'] ) ) ? $e['links'] : array();
	$names = ( isset( $e['segment_names'] ) && is_array( $e['segment_names'] ) ) ? $e['segment_names'] : array();
	$tags  = ! empty( $e['tln_pick'] ) ? '<span class="is-pick">' . esc_html__( 'TLN pick', 'tln-conference-calendar' ) . '</span>' : '';
	foreach ( $e['segments'] as $i => $slug ) {
		if ( 'tln-picks' !== $slug && isset( $names[ $i ] ) && is_scalar( $names[ $i ] ) ) {
			$tags .= '<span>' . esc_html( (string) $names[ $i ] ) . '</span>';
		}
	}
	$event_url = tln_cc_str( $e, 'event_url' );
	$reg_url   = tln_cc_str( $e, 'registration_url' );
	$title_url = $event_url ? $event_url : $reg_url;
	$title     = $title_url
		? '<a href="' . esc_url( $title_url ) . '" target="_blank" rel="noopener">' . esc_html( tln_cc_str( $e, 'title' ) ) . '</a>'
		: esc_html( tln_cc_str( $e, 'title' ) );
	$org_bits  = array_filter( array( tln_cc_str( $e, 'organizer' ), tln_cc_str( $e, 'format_label' ), tln_cc_str( $e, 'cost' ) ) );
	$text      = strtolower( implode( ' ', array( tln_cc_str( $e, 'title' ), tln_cc_str( $e, 'organizer' ), tln_cc_str( $e, 'location' ), tln_cc_str( $e, 'summary' ), implode( ' ', array_filter( $names, 'is_scalar' ) ) ) ) );
	$badge     = ( isset( $e['badge'] ) && is_array( $e['badge'] ) ) ? $e['badge'] : array();

	$out  = '<article class="tlncc-ev" id="e-' . esc_attr( tln_cc_str( $e, 'id' ) ) . '" data-segs="' . esc_attr( 'all ' . implode( ' ', $e['segments'] ) ) . '" data-text="' . esc_attr( $text ) . '">';
	$out .= '<div class="tlncc-badge" aria-hidden="true"><span class="m">' . esc_html( tln_cc_str( $badge, 'month' ) ) . '</span><span class="d">' . esc_html( tln_cc_str( $badge, 'day' ) ) . '</span>';
	if ( '' !== tln_cc_str( $badge, 'range' ) ) {
		$out .= '<span class="r">' . esc_html( tln_cc_str( $badge, 'range' ) ) . '</span>';
	}
	$out .= '</div><div class="tlncc-body">';
	if ( $tags && ! $compact ) {
		$out .= '<p class="tlncc-tags">' . $tags . '</p>';
	}
	$out .= '<h4 class="tlncc-title">' . $title . '</h4>';
	$out .= '<p class="tlncc-when">' . esc_html( tln_cc_str( $e, 'when' ) ) . '</p>';
	$out .= '<p class="tlncc-where">' . esc_html( tln_cc_str( $e, 'location' ) ) . '</p>';
	if ( $org_bits && ! $compact ) {
		$out .= '<p class="tlncc-org">' . esc_html( implode( ' · ', $org_bits ) ) . '</p>';
	}
	if ( '' !== tln_cc_str( $e, 'summary' ) && ! $compact ) {
		$out .= '<p class="tlncc-sum">' . esc_html( tln_cc_str( $e, 'summary' ) ) . '</p>';
	}
	$out .= '<div class="tlncc-actions"><details class="tlncc-add"><summary>' . esc_html__( 'Add to calendar', 'tln-conference-calendar' ) . '</summary><div class="tlncc-menu">';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'google' ) ) . '" target="_blank" rel="noopener">Google Calendar</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '">Apple Calendar (.ics)</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'outlook' ) ) . '" target="_blank" rel="noopener">Outlook.com</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'office' ) ) . '" target="_blank" rel="noopener">Outlook for work</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '" download>' . esc_html__( 'Download .ics file', 'tln-conference-calendar' ) . '</a>';
	$out .= '</div></details>';
	if ( $event_url ) {
		$out .= '<a class="tlncc-link" href="' . esc_url( $event_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Event page', 'tln-conference-calendar' ) . '</a>';
	}
	if ( $reg_url && ! $compact ) {
		$out .= '<a class="tlncc-link" href="' . esc_url( $reg_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Register', 'tln-conference-calendar' ) . '</a>';
	}
	$out .= '</div></div></article>';
	return $out;
}

/** Use publisher-provided API links; legacy D.C. feeds retain their old URLs. */
function tln_cc_api_url( $data, $key, $region = 'dc' ) {
	if ( isset( $data['api'] ) && is_array( $data['api'] ) && array_key_exists( $key, $data['api'] ) ) {
		return tln_cc_str( $data['api'], $key );
	}
	$base = untrailingslashit( tln_cc_str( $data, 'base_url' ) );
	if ( 'dc' === $region && $base ) {
		return $base . '/api/events.' . ( 'csv' === $key ? 'csv' : 'json' );
	}
	$url = tln_cc_region_source_url( $region );
	return 'csv' === $key ? preg_replace( '/\.json$/', '.csv', $url ) : $url;
}

function tln_cc_render_footer( $data, $theme, $compact, $region = 'dc' ) {
	$submit  = tln_cc_str( $data, 'submit_url' );
	$page_id = (int) get_option( 'tln_cc_page_id' );
	$full    = $page_id ? get_permalink( $page_id ) : tln_cc_str( $data, 'page_url' );
	$full    = $full ? tln_cc_region_page_url( $region, $full ) : '';
	$out     = '<footer class="tlncc-foot">';
	if ( $compact && $full ) {
		$out .= '<a href="' . esc_url( 'all' === $theme ? $full : add_query_arg( 'theme', $theme, $full ) ) . '">' . esc_html__( 'See the full calendar', 'tln-conference-calendar' ) . '</a>';
	} else {
		/* translators: %s: date the calendar was last updated */
		$out .= esc_html( sprintf( __( 'Updated %s.', 'tln-conference-calendar' ), tln_cc_str( $data, 'updated_label' ) ) ) . ' ';
		if ( $submit ) {
			$out .= '<a href="' . esc_url( $submit ) . '" target="_blank" rel="noopener">' . esc_html__( 'Suggest an event', 'tln-conference-calendar' ) . '</a> · ';
		}
		$json = tln_cc_api_url( $data, 'json', $region );
		$csv  = tln_cc_api_url( $data, 'csv', $region );
		if ( $json || $csv ) {
			$out .= '<a href="' . esc_url( $json ) . '">JSON</a> · <a href="' . esc_url( $csv ) . '">CSV</a> · ';
		}
		$out .= esc_html( tln_cc_str( $data, 'note' ) );
	}
	return $out . '</footer>';
}

/* schema.org Event markup so search engines can show these as events. */
function tln_cc_render_schema( $events ) {
	$graph = array();
	foreach ( array_slice( $events, 0, 100 ) as $e ) {
		if ( isset( $e['schema'] ) && is_array( $e['schema'] ) ) {
			$graph[] = $e['schema'];
		}
	}
	if ( ! $graph ) {
		return '';
	}
	$json = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
	);
	return $json ? '<script type="application/ld+json">' . $json . '</script>' : '';
}

/* ------------------------------------------------------------------ wall calendar */

/** Months whose photo stays off the wall (set under Settings > Conference Calendar). Format: YYYY-MM. */
function tln_cc_parse_months( $raw ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY ) as $m ) {
		if ( preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $m ) && ! in_array( $m, $out, true ) ) {
			$out[] = $m;
		}
	}
	return $out;
}

function tln_cc_sanitize_months( $value ) {
	return implode( ', ', tln_cc_parse_months( is_scalar( $value ) ? (string) $value : '' ) );
}

/** A run of consecutive months, as YYYY-MM strings. */
function tln_cc_month_run( $ym, $n ) {
	$d   = DateTime::createFromFormat( '!Y-m-d', $ym . '-01', new DateTimeZone( 'America/New_York' ) );
	$out = array();
	if ( ! $d ) {
		return $out;
	}
	for ( $i = 0; $i < $n; $i++ ) {
		$out[] = $d->format( 'Y-m' );
		$d->modify( 'first day of next month' );
	}
	return $out;
}

/**
 * The twelve photo months of the printed wall calendar (Dec. 2026 to Nov. 2027), plus any months
 * between today and the first photo month. After the year ends it simply rolls on from this month.
 */
function tln_cc_wall_months( $today ) {
	$start = (string) apply_filters( 'tln_cc_wall_start', '2026-12' );
	if ( ! preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $start ) ) {
		$start = '2026-12';
	}
	$cur  = substr( $today, 0, 7 );
	$core = tln_cc_month_run( $start, 12 );
	if ( $cur > end( $core ) ) {
		return array(
			'months'  => tln_cc_month_run( $cur, 12 ),
			'core'    => array(),
			'default' => $cur,
		);
	}
	$months = $core;
	if ( $cur < $start ) {
		$before = array();
		foreach ( tln_cc_month_run( $cur, 24 ) as $m ) {
			if ( $m < $start ) {
				$before[] = $m;
			}
		}
		$months = array_merge( $before, $core );
	}
	return array(
		'months'  => $months,
		'core'    => $core,
		'default' => $cur < $start ? $start : $cur,
	);
}

/** Month number (1-12) to the shop print for that month. Needs WooCommerce products with _tln_calendar_month. */
function tln_cc_wall_products() {
	$map = array();
	if ( ! function_exists( 'get_posts' ) || ! function_exists( 'get_post_meta' ) ) {
		return $map;
	}
	$ids = get_posts(
		array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
			'meta_key'       => '_tln_calendar_month', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'posts_per_page' => 24,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	foreach ( (array) $ids as $id ) {
		$m = (int) get_post_meta( $id, '_tln_calendar_month', true );
		if ( $m < 1 || $m > 12 || isset( $map[ $m ] ) ) {
			continue;
		}
		$map[ $m ] = array(
			'id'     => (int) $id,
			'title'  => html_entity_decode( strip_tags( (string) get_the_title( $id ) ), ENT_QUOTES, 'UTF-8' ),
			'status' => (string) get_post_status( $id ),
			'thumb'  => function_exists( 'get_post_thumbnail_id' ) ? (int) get_post_thumbnail_id( $id ) : 0,
			'url'    => (string) get_permalink( $id ),
		);
	}
	return $map;
}

/** The buy link only exists once the print is published and the shop is open to the public. */
function tln_cc_wall_buy_url( $product ) {
	if ( ! $product || 'publish' !== $product['status'] || 'yes' === (string) get_option( 'woocommerce_coming_soon', 'no' ) ) {
		return '';
	}
	return (string) apply_filters( 'tln_cc_wall_buy_url', $product['url'], $product );
}

function tln_cc_wall_img( $product, $eager ) {
	if ( ! $product || ! $product['thumb'] || ! function_exists( 'wp_get_attachment_image' ) ) {
		return '';
	}
	return (string) wp_get_attachment_image(
		$product['thumb'],
		'large',
		false,
		array(
			'class'    => 'tlncc-pic-img',
			'alt'      => $product['title'],
			'loading'  => $eager ? 'eager' : 'lazy',
			'decoding' => 'async',
			'sizes'    => '(min-width: 980px) 464px, 100vw',
		)
	);
}

function tln_cc_ap_month( $n ) {
	$names = array( 1 => 'Jan.', 2 => 'Feb.', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'Aug.', 9 => 'Sept.', 10 => 'Oct.', 11 => 'Nov.', 12 => 'Dec.' );
	return isset( $names[ (int) $n ] ) ? $names[ (int) $n ] : '';
}

/** "Tuesday, Dec. 1, 9 a.m. to 5:30 p.m." becomes "9 a.m. to 5:30 p.m."; all-day and multi-day events keep a short label. */
function tln_cc_wall_time_label( $e ) {
	$when = trim( tln_cc_str( $e, 'when' ) );
	$rest = preg_replace( '/^(?:[A-Za-z]+day,\s+)?[A-Za-z]{3,9}\.?\s+\d{1,2}(?:\s*[–-]\s*\d{1,2})?(?:,\s*\d{4})?(?:,\s*|$)/u', '', $when, 1 );
	if ( null === $rest || '' === trim( $rest ) ) {
		return tln_cc_str( $e, 'end_date' ) > tln_cc_str( $e, 'start_date' ) && '' !== $when ? $when : __( 'All day', 'tln-conference-calendar' );
	}
	return trim( $rest );
}

/** Spread every event over each day it covers, limited to the months shown. */
function tln_cc_wall_days( $upcoming, $first, $last ) {
	$tz    = new DateTimeZone( 'America/New_York' );
	$byday = array();
	foreach ( $upcoming as $e ) {
		$s = tln_cc_str( $e, 'start_date' );
		$f = tln_cc_str( $e, 'end_date' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s ) ) {
			continue;
		}
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $f ) || $f < $s ) {
			$f = $s;
		}
		$d = DateTime::createFromFormat( '!Y-m-d', $s, $tz );
		for ( $i = 0; $d && $i < 62; $i++ ) {
			$k = $d->format( 'Y-m-d' );
			if ( $k > $f || $k > $last ) {
				break;
			}
			if ( $k >= $first ) {
				$byday[ $k ][] = $e;
			}
			$d->modify( '+1 day' );
		}
	}
	foreach ( $byday as $k => $list ) {
		usort(
			$list,
			function ( $x, $y ) {
				return strcmp( tln_cc_str( $x, 'start_time' ) . '|' . tln_cc_str( $x, 'title' ), tln_cc_str( $y, 'start_time' ) . '|' . tln_cc_str( $y, 'title' ) );
			}
		);
		$byday[ $k ] = $list;
	}
	return $byday;
}

/**
 * The wall calendar: one sheet per month with the month's photo, a day grid with event dots, circled
 * TLN picks and a day panel. Server-rendered so it works without JavaScript; tlncc.js adds paging and the panel.
 */
function tln_cc_render_wall( $upcoming, $today ) {
	$tz     = new DateTimeZone( 'America/New_York' );
	$plan   = tln_cc_wall_months( $today );
	$months = $plan['months'];
	if ( ! $months ) {
		return '';
	}
	$first    = $months[0] . '-01';
	$lastday  = DateTime::createFromFormat( '!Y-m-d', end( $months ) . '-01', $tz );
	$last     = $lastday ? $lastday->format( 'Y-m-t' ) : $first;
	$byday    = tln_cc_wall_days( $upcoming, $first, $last );
	$hidden   = tln_cc_parse_months( get_option( 'tln_cc_wall_hidden', '' ) );
	$products = tln_cc_wall_products();
	$default  = in_array( $plan['default'], $months, true ) ? $plan['default'] : $months[0];
	$weekdays = array( 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' );

	$out  = '<aside class="tlncc-wall" data-wall data-today="' . esc_attr( $today ) . '" data-default="' . esc_attr( $default ) . '" aria-label="' . esc_attr__( 'Wall calendar', 'tln-conference-calendar' ) . '">';
		$out .= '<div class="tlncc-sheet">';

	foreach ( $months as $ym ) {
		$d1 = DateTime::createFromFormat( '!Y-m-d', $ym . '-01', $tz );
		if ( ! $d1 ) {
			continue;
		}
		$name  = $d1->format( 'F' );
		$year  = $d1->format( 'Y' );
		$dim   = (int) $d1->format( 't' );
		$lead  = (int) $d1->format( 'w' );
		$cells = (int) ( ceil( ( $lead + $dim ) / 7 ) * 7 );
		$core  = in_array( $ym, $plan['core'], true );

		/* Photo, caption and buy link. A hidden month, or a missing product or image, gets the plain masthead header. */
		$product = null;
		if ( $core && ! in_array( $ym, $hidden, true ) ) {
			$num     = (int) $d1->format( 'n' );
			$product = isset( $products[ $num ] ) ? $products[ $num ] : null;
		}
		$img = $product ? tln_cc_wall_img( $product, $ym === $default ) : '';
		$buy = $img ? tln_cc_wall_buy_url( $product ) : '';
		$cap = '<span class="tlncc-cap-t"><em>' . esc_html( $name ) . '</em>' . ( $img ? ' &middot; ' . esc_html( $product['title'] ) : '' ) . '</span>';
		if ( $buy ) {
			$cap .= '<a class="tlncc-buy" href="' . esc_url( $buy ) . '">' . esc_html__( 'Buy this print', 'tln-conference-calendar' ) . ' <span aria-hidden="true">&rarr;</span></a>';
		}
		$photo = $img
			? '<div class="tlncc-pic">' . $img . '</div>'
			: '<div class="tlncc-pic is-blank" aria-hidden="true"><span class="w">The Local National</span><span class="s">' . esc_html__( 'D.C. Conference Calendar', 'tln-conference-calendar' ) . '</span></div>';

		/* Day grid, per-day lists and the month's event count. */
		$grid  = '';
		$lists = '';
		$ids   = array();
		for ( $c = 0; $c < $cells; $c++ ) {
			if ( 0 === $c % 7 ) {
				$grid .= '<tr>';
			}
			$n = $c - $lead + 1;
			if ( $n < 1 || $n > $dim ) {
				$grid .= '<td class="is-off"></td>';
			} else {
				$date  = $ym . '-' . sprintf( '%02d', $n );
				$dow   = $c % 7;
				$items = isset( $byday[ $date ] ) ? $byday[ $date ] : array();
				$cls   = 'tlncc-d' . ( $date === $today ? ' is-today' : '' );
				$td    = 'tlncc-c' . ( 0 === $dow || 6 === $dow ? ' is-we' : '' );
				if ( ! $items ) {
					$grid .= '<td class="' . $td . '"><span class="' . $cls . '" data-date="' . esc_attr( $date ) . '"><span class="n">' . $n . '</span></span></td>';
				} else {
					$label = $weekdays[ $dow ] . ', ' . tln_cc_ap_month( $d1->format( 'n' ) ) . ' ' . $n;
					$total = count( $items );
					$pick  = false;
					$dots  = '';
					$li    = '';
					foreach ( $items as $i => $e ) {
						$eid         = tln_cc_str( $e, 'id' );
						$ids[ $eid ] = true;
						if ( ! empty( $e['tln_pick'] ) ) {
							$pick = true;
						}
						if ( $i < 4 ) {
							$dots .= '<i></i>';
						}
						$li .= '<li data-ev="' . esc_attr( $eid ) . '"' . ( ! empty( $e['tln_pick'] ) ? ' data-pick="1"' : '' ) . '><a href="#e-' . esc_attr( $eid ) . '"><span class="t">' . esc_html( tln_cc_wall_time_label( $e ) ) . '</span><span class="n">' . esc_html( tln_cc_str( $e, 'title' ) ) . '</span></a></li>';
					}
					if ( $total > 4 ) {
						$dots .= '<b>+' . ( $total - 4 ) . '</b>';
					}
					$aria  = $label . ', ' . $total . ( 1 === $total ? ' event' : ' events' );
					$grid .= '<td class="' . $td . '"><button type="button" class="' . $cls . ( $pick ? ' has-pick' : '' ) . '" data-date="' . esc_attr( $date ) . '" aria-pressed="false" aria-label="' . esc_attr( $aria ) . '"><span class="n">' . $n . '</span><span class="tlncc-dots" aria-hidden="true">' . $dots . '</span></button></td>';
					$lists .= '<ul class="tlncc-dl" data-date="' . esc_attr( $date ) . '" data-label="' . esc_attr( $label ) . '">' . $li . '</ul>';
				}
			}
			if ( 6 === $c % 7 ) {
				$grid .= '</tr>';
			}
		}
		$count       = count( $ids );
		$count_label = $count ? $count . ( 1 === $count ? ' event this month' : ' events this month' ) : 'No events listed this month';

		$head = '';
		foreach ( array( 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ) as $full ) {
			$head .= '<th scope="col" abbr="' . esc_attr( $full ) . '">' . esc_html( substr( $full, 0, 1 ) ) . '</th>';
		}

		$out .= '<section class="tlncc-mo" data-month="' . esc_attr( $ym ) . '"' . ( $core ? ' data-core="1"' : '' ) . ( $ym === $default ? '' : ' hidden' ) . ' aria-label="' . esc_attr( $name . ' ' . $year ) . '">';
		$out .= '<figure class="tlncc-photo">' . $photo . '<figcaption class="tlncc-cap">' . $cap . '</figcaption></figure>';
		$out .= '<div class="tlncc-rings" aria-hidden="true"></div>';
		$out .= '<div class="tlncc-mhd">';
		$out .= '<button type="button" class="tlncc-nav" data-wall-go="-1" aria-label="' . esc_attr__( 'Previous month', 'tln-conference-calendar' ) . '"><svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true" focusable="false"><path d="M10 3 L5 8 L10 13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
		$out .= '<h2 class="tlncc-mt">' . esc_html( $name ) . ' <span>' . esc_html( $year ) . '</span></h2>';
		$out .= '<button type="button" class="tlncc-nav" data-wall-go="1" aria-label="' . esc_attr__( 'Next month', 'tln-conference-calendar' ) . '"><svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true" focusable="false"><path d="M6 3 L11 8 L6 13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
		$out .= '</div>';
		$out .= '<table class="tlncc-grid"><caption class="tlncc-vh">' . esc_html( $name . ' ' . $year ) . '</caption><thead><tr>' . $head . '</tr></thead><tbody>' . $grid . '</tbody></table>';
		$out .= '<div class="tlncc-dls" hidden>' . $lists . '</div>';
		$out .= '<div class="tlncc-panel" data-panel aria-live="polite"></div>';
		$out .= '<p class="tlncc-legend"><span class="k"><i class="k-dot"></i>' . esc_html__( 'event', 'tln-conference-calendar' ) . '</span><span class="k"><i class="k-ring"></i>' . esc_html__( 'TLN pick', 'tln-conference-calendar' ) . '</span><span class="k-n" data-lc>' . esc_html( $count_label ) . '</span></p>';
		$out .= '</section>';
	}

	return $out . '</div></aside>';
}

/* ------------------------------------------------------------------ refresh schedule */

/** Attempt both cities even when one fails; optionally clear both transients. */
function tln_cc_refresh_all( $clear = false ) {
	$ok = true;
	foreach ( array( 'dc', 'baltimore' ) as $region ) {
		if ( $clear ) {
			delete_transient( tln_cc_cache_key( 'tln_cc_data', $region ) );
		}
		if ( ! tln_cc_fetch( $region ) ) {
			$ok = false;
		}
	}
	return $ok;
}

add_action( 'tln_cc_refresh', 'tln_cc_refresh_all' );

register_activation_hook( __FILE__, 'tln_cc_activate' );
function tln_cc_activate() {
	if ( ! wp_next_scheduled( 'tln_cc_refresh' ) ) {
		wp_schedule_event( time() + 60, 'hourly', 'tln_cc_refresh' );
	}
	tln_cc_refresh_all();
	tln_cc_create_page();
}

register_deactivation_hook( __FILE__, 'tln_cc_deactivate' );
function tln_cc_deactivate() {
	wp_clear_scheduled_hook( 'tln_cc_refresh' );
}

/* Creates the calendar page once (at /conferences/), as a draft unless the build says publish. */
function tln_cc_create_page() {
	$existing_id = (int) get_option( 'tln_cc_page_id' );
	if ( $existing_id && get_post( $existing_id ) ) {
		return $existing_id;
	}
	$existing = get_page_by_path( 'conferences', OBJECT, 'page' );
	if ( $existing ) {
		update_option( 'tln_cc_page_id', (int) $existing->ID, false );
		return (int) $existing->ID;
	}
	$author = get_current_user_id();
	if ( ! $author ) {
		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		$author = $admins ? (int) $admins[0] : 0;
	}
	$status  = in_array( TLN_CC_PAGE_STATUS, array( 'publish', 'draft' ), true ) ? TLN_CC_PAGE_STATUS : 'draft';
	$intro   = 'Conferences, summits and public forums in Washington, D.C. that show where national issues are headed. Subscribe to the whole calendar or only the topics you follow, or add single events to your own calendar. Updated every morning.';
	$content = "<!-- wp:paragraph -->\n<p>" . esc_html( $intro ) . "</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[tln_conferences]\n<!-- /wp:shortcode -->";
	$id      = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => $status,
			'post_title'   => 'D.C. Conference Calendar',
			'post_name'    => 'conferences',
			'post_content' => $content,
			'post_excerpt' => $intro,
			'post_author'  => $author,
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_option( 'tln_cc_page_id', (int) $id, false );
	return (int) $id;
}

/* ------------------------------------------------------------------ coming up
   Two promos for the calendar, added from here so a theme release cannot drop them:
   a strip under the site header on every page, and a "Coming up" section on the
   home page just above Issues. Both can be switched off in Settings. */
function tln_cc_calendar_url() {
	$id  = (int) get_option( 'tln_cc_page_id' );
	$url = $id ? (string) get_permalink( $id ) : '';
	return '' !== $url ? $url : home_url( '/conferences/' );
}
/** Upcoming D.C. events in date order; empty when the feed is unavailable. */
function tln_cc_upcoming_dc() {
	$data = tln_cc_data( 'dc' );
	if ( ! $data ) {
		return array();
	}
	$today = tln_cc_today();
	$out   = array();
	foreach ( $data['events'] as $e ) {
		if ( is_array( $e ) && '' !== tln_cc_str( $e, 'id' ) && '' !== tln_cc_str( $e, 'title' ) && tln_cc_str( $e, 'end_date' ) >= $today ) {
			$out[] = $e;
		}
	}
	usort(
		$out,
		function ( $x, $y ) {
			return strcmp( tln_cc_str( $x, 'start_date' ) . ' ' . tln_cc_str( $x, 'start_time' ), tln_cc_str( $y, 'start_date' ) . ' ' . tln_cc_str( $y, 'start_time' ) );
		}
	);
	return $out;
}
function tln_cc_cu_link( $e ) {
	return tln_cc_calendar_url() . '#e-' . rawurlencode( tln_cc_str( $e, 'id' ) );
}
/** Whether a promo ('strip' or 'home') belongs on the page being rendered. */
function tln_cc_coming_up_on( $which ) {
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ) {
		return false;
	}
	if ( ( function_exists( 'is_feed' ) && is_feed() ) || ( function_exists( 'is_embed' ) && is_embed() ) ) {
		return false;
	}
	if ( 'no' === get_option( 'tln_cc_coming_up_' . $which, 'yes' ) ) {
		return false;
	}
	if ( 'strip' === $which ) {
		if ( tln_cc_page_has_shortcode() ) {
			return false;
		}
		if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() ) ) {
			return false;
		}
	}
	if ( 'home' === $which && ! ( function_exists( 'is_front_page' ) && is_front_page() ) ) {
		return false;
	}
	return (bool) apply_filters( 'tln_cc_coming_up_' . $which, true );
}
function tln_cc_cu_date( $e, $today ) {
	$start = tln_cc_str( $e, 'start_date' );
	if ( $start < $today ) {
		return __( 'Underway', 'tln-conference-calendar' );
	}
	$d = DateTime::createFromFormat( '!Y-m-d', $start, new DateTimeZone( 'America/New_York' ) );
	return $d ? tln_cc_ap_month( $d->format( 'n' ) ) . ' ' . $d->format( 'j' ) : $start;
}
/** A: one line under the menu with the next three events. */
function tln_cc_render_strip( $upcoming ) {
	if ( ! $upcoming ) {
		return '';
	}
	tln_cc_cu_styles();
	$today = tln_cc_today();
	$items = '';
	foreach ( array_slice( $upcoming, 0, 3 ) as $e ) {
		$items .= '<li><a href="' . esc_url( tln_cc_cu_link( $e ) ) . '"><span class="d">' . esc_html( tln_cc_cu_date( $e, $today ) ) . '</span><span class="t">' . esc_html( tln_cc_str( $e, 'title' ) ) . '</span></a></li>';
	}
	$url = tln_cc_calendar_url();
	return '<div class="tlncc-cu-wrap"><nav class="tlncc-strip" aria-label="' . esc_attr__( 'Coming up in D.C.', 'tln-conference-calendar' ) . '">'
		. '<a class="tlncc-strip-label" href="' . esc_url( $url ) . '">' . esc_html__( 'Coming up in D.C.', 'tln-conference-calendar' ) . '</a>'
		. '<ol>' . $items . '</ol>'
	/* translators: %d: number of upcoming events */
		. '<a class="tlncc-strip-all" href="' . esc_url( $url ) . '">' . esc_html( sprintf( __( 'All %d', 'tln-conference-calendar' ), count( $upcoming ) ) ) . ' &rarr;</a>'
		. '</nav></div>';
}
/** B: a home-page section in the style of the other lanes, with the next four events. */
function tln_cc_render_home( $upcoming ) {
	if ( ! $upcoming ) {
		return '';
	}
	tln_cc_cu_styles();
	$tz    = new DateTimeZone( 'America/New_York' );
	$today = tln_cc_today();
	$cards = '';
	foreach ( array_slice( $upcoming, 0, 4 ) as $e ) {
		$start = tln_cc_str( $e, 'start_date' ) < $today ? $today : tln_cc_str( $e, 'start_date' );
		$d     = DateTime::createFromFormat( '!Y-m-d', $start, $tz );
		$names = isset( $e['segment_names'] ) && is_array( $e['segment_names'] ) ? array_values( $e['segment_names'] ) : array();
		$kick  = $names && is_scalar( $names[0] ) ? (string) $names[0] : '';
		$meta  = array_filter( array( tln_cc_str( $e, 'organizer' ), tln_cc_wall_time_label( $e ) ) );
		$cards .= '<li class="tlncc-home-card"><a href="' . esc_url( tln_cc_cu_link( $e ) ) . '">'
			. '<span class="tlncc-home-date"><span class="m">' . esc_html( $d ? $d->format( 'M' ) : '' ) . '</span><span class="dd">' . esc_html( $d ? $d->format( 'j' ) : '' ) . '</span><span class="wd">' . esc_html( $d ? $d->format( 'D' ) : '' ) . '</span></span>'
			. '<span class="tlncc-home-text">' . ( '' !== $kick ? '<span class="ln-k">' . esc_html( $kick ) . '</span>' : '' )
			. '<span class="tlncc-home-h">' . esc_html( tln_cc_str( $e, 'title' ) ) . '</span>'
			. '<span class="tlncc-home-meta">' . esc_html( implode( ' · ', $meta ) ) . '</span></span></a></li>';
	}
	$url = tln_cc_calendar_url();
	return '<section class="ln-lane tlncc-home" aria-labelledby="tlncc-home-title">'
		. '<div class="ln-lanehead tlncc-home-head"><h2 class="ln-lane-title" id="tlncc-home-title"><a href="' . esc_url( $url ) . '">' . esc_html__( 'Coming up', 'tln-conference-calendar' ) . '</a></h2>'
		. '<p class="ln-lane-desc">' . esc_html__( 'Conferences, summits and public forums in Washington that show where national issues are headed. Updated every morning.', 'tln-conference-calendar' ) . '</p></div>'
		. '<ol class="tlncc-home-cards">' . $cards . '</ol>'
		. '<div class="tlncc-home-foot"><a class="tlncc-home-btn" href="' . esc_url( $url ) . '">'
	/* translators: %d: number of upcoming events */
		. esc_html( sprintf( __( 'See all %d events', 'tln-conference-calendar' ), count( $upcoming ) ) ) . '</a>'
		. '<a class="tlncc-home-btn is-line" href="' . esc_url( $url . '#subscribe' ) . '">' . esc_html__( 'Put them on your calendar', 'tln-conference-calendar' ) . '</a></div>'
		. '</section>';
}
/** Small stylesheet for both promos, printed in the head (block themes render the template before wp_head). */
function tln_cc_cu_styles() {
	if ( ! empty( $GLOBALS['tln_cc_cu_css'] ) || ! function_exists( 'wp_add_inline_style' ) ) {
		return;
	}
	$GLOBALS['tln_cc_cu_css'] = true;
	wp_register_style( 'tln-cc-coming-up', false, array(), TLN_CC_VERSION );
	wp_add_inline_style( 'tln-cc-coming-up', TLN_CC_CU_CSS );
	wp_enqueue_style( 'tln-cc-coming-up' );
}
define(
	'TLN_CC_CU_CSS',
	'.tlncc-cu-wrap{padding-left:var(--wp--style--root--padding-left,1rem);padding-right:var(--wp--style--root--padding-right,1rem)}'
		. '.tlncc-strip{display:flex;align-items:center;gap:22px;max-width:var(--wp--style--global--wide-size,1280px);margin:0 auto;border-bottom:1px solid var(--wp--preset--color--ink,#1A1714);padding:12px 0 13px;font-family:var(--wp--preset--font-family--label,Archivo,Helvetica,Arial,sans-serif)}'
		. '.tlncc-strip a{color:var(--wp--preset--color--ink,#1A1714);text-decoration:none}'
		. '.tlncc-strip .tlncc-strip-label{font-weight:800;font-stretch:110%;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;color:var(--wp--preset--color--red,#BF2A1E);white-space:nowrap}'
		. '.tlncc-strip ol{display:flex;list-style:none;margin:0;padding:0;flex:1;min-width:0}'
		. '.tlncc-strip li{flex:1 1 0;min-width:0;margin:0;padding:0 18px;border-left:1px solid rgba(26,23,20,.28)}'
		. '.tlncc-strip li a{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:.8125rem}'
		. '.tlncc-strip .d{font-weight:800;font-stretch:110%;letter-spacing:.04em;text-transform:uppercase;margin-right:8px}'
		. '.tlncc-strip .t{font-family:var(--wp--preset--font-family--text,Newsreader,Georgia,serif);font-size:1rem}'
		. '.tlncc-strip li a:hover .t,.tlncc-strip li a:focus-visible .t{color:var(--wp--preset--color--red,#BF2A1E)}'
		. '.tlncc-strip .tlncc-strip-all{white-space:nowrap;font-weight:800;font-stretch:110%;font-size:.75rem;letter-spacing:.12em;text-transform:uppercase}'
		. '@media (max-width:899px){.tlncc-strip{flex-wrap:wrap;gap:6px 12px;padding:12px 0 6px}.tlncc-strip ol{order:3;flex:0 0 100%;flex-direction:column}.tlncc-strip li{border-left:0;padding:9px 0;border-top:1px solid rgba(26,23,20,.18)}.tlncc-strip li a{white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.tlncc-strip .tlncc-strip-all{margin-left:auto}}'
		. '.tlncc-home-head{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:baseline}'
		. '.tlncc-home-cards{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0 32px}'
		. '.tlncc-home-card{margin:0;border-top:1px solid var(--wp--preset--color--ink,#1A1714);padding-top:16px}'
		. '.tlncc-home-card a{display:flex;gap:16px;color:var(--wp--preset--color--ink,#1A1714);text-decoration:none}'
		. '.tlncc-home-date{flex:0 0 58px;display:flex;flex-direction:column;align-items:center;border:1.5px solid var(--wp--preset--color--ink,#1A1714);background:#fff;padding:5px 0 6px;line-height:1;height:max-content}'
		. '.tlncc-home-date .m{font-family:var(--wp--preset--font-family--label,Archivo,sans-serif);font-weight:800;font-stretch:110%;font-size:.6875rem;letter-spacing:.14em;text-transform:uppercase;color:var(--wp--preset--color--red,#BF2A1E)}'
		. '.tlncc-home-date .dd{font-family:var(--wp--preset--font-family--display,Fraunces,Georgia,serif);font-weight:900;font-size:1.875rem;letter-spacing:-.03em;margin:3px 0 2px}'
		. '.tlncc-home-date .wd{font-family:var(--wp--preset--font-family--label,Archivo,sans-serif);font-weight:700;font-size:.6875rem;letter-spacing:.1em;text-transform:uppercase;color:var(--wp--preset--color--meta,#5C554B)}'
		. '.tlncc-home-text{min-width:0;display:flex;flex-direction:column;gap:6px}'
		. '.tlncc-home-h{font-family:var(--wp--preset--font-family--display,Fraunces,Georgia,serif);font-weight:700;font-size:1.1875rem;line-height:1.12;letter-spacing:-.015em;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;font-variation-settings:"SOFT" 70,"WONK" 0}'
		. '.tlncc-home-card a:hover .tlncc-home-h,.tlncc-home-card a:focus-visible .tlncc-home-h{color:var(--wp--preset--color--red,#BF2A1E)}'
		. '.tlncc-home-meta{font-family:var(--wp--preset--font-family--label,Archivo,sans-serif);font-size:.8125rem;color:var(--wp--preset--color--meta,#5C554B)}'
		. '.tlncc-home-foot{display:flex;gap:12px;flex-wrap:wrap;margin-top:26px}'
		. '.tlncc-home-btn{font-family:var(--wp--preset--font-family--label,Archivo,sans-serif);font-weight:700;font-size:.9375rem;padding:12px 18px;background:var(--wp--preset--color--ink,#1A1714);color:var(--wp--preset--color--paper,#F3EBDD)!important;text-decoration:none;border:1.5px solid var(--wp--preset--color--ink,#1A1714)}'
		. '.tlncc-home-btn.is-line{background:transparent;color:var(--wp--preset--color--ink,#1A1714)!important}'
		. '@media (max-width:1100px){.tlncc-home-cards{grid-template-columns:repeat(2,minmax(0,1fr));gap:20px 32px}}'
		. '@media (max-width:640px){.tlncc-home-cards{grid-template-columns:minmax(0,1fr);gap:0}.tlncc-home-card{padding:14px 0}.tlncc-home-btn{flex:1 1 100%;text-align:center}}'
);
/** Add the strip after the site header and the section above Issues on the home page; each once per page. */
function tln_cc_coming_up_block( $html, $block ) {
	$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	if ( ! isset( $GLOBALS['tln_cc_cu_done'] ) ) {
		$GLOBALS['tln_cc_cu_done'] = array();
	}
	$done = &$GLOBALS['tln_cc_cu_done'];
	if ( 'core/template-part' === $name && empty( $done['strip'] ) ) {
		$slug = isset( $block['attrs']['slug'] ) ? (string) $block['attrs']['slug'] : '';
		if ( in_array( $slug, array( 'header', 'header-compact' ), true ) && tln_cc_coming_up_on( 'strip' ) ) {
			$done['strip'] = true;
			return $html . tln_cc_render_strip( tln_cc_upcoming_dc() );
		}
	}
	if ( 'core/group' === $name && empty( $done['home'] ) ) {
		$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
		if ( preg_match( '/(^|\s)ln-lane-issues(\s|$)/', $class ) && tln_cc_coming_up_on( 'home' ) ) {
			$done['home'] = true;
			return tln_cc_render_home( tln_cc_upcoming_dc() ) . $html;
		}
	}
	return $html;
}
add_filter( 'render_block', 'tln_cc_coming_up_block', 10, 2 );
function tln_cc_sanitize_yes_no( $value ) {
	return tln_cc_yes( is_scalar( $value ) ? (string) $value : '' ) ? 'yes' : 'no';
}
/* ------------------------------------------------------------------ settings */

add_action(
	'admin_init',
	function () {
		register_setting(
			'tln_cc',
			'tln_cc_source_url',
			array(
				'type'              => 'string',
					'sanitize_callback' => 'esc_url_raw',
					'default'           => '',
				)
			);
			foreach ( array( 'tln_cc_coming_up_strip', 'tln_cc_coming_up_home' ) as $tln_cc_switch ) {
				register_setting(
					'tln_cc',
					$tln_cc_switch,
					array(
						'type'              => 'string',
						'sanitize_callback' => 'tln_cc_sanitize_yes_no',
						'default'           => 'yes',
					)
				);
			}
			register_setting(
				'tln_cc',
				'tln_cc_wall_hidden',
				array(
					'type'              => 'string',
					'sanitize_callback' => 'tln_cc_sanitize_months',
					'default'           => '',
				)
			);
		}
	);

add_action(
	'admin_menu',
	function () {
		add_options_page( 'Conference Calendar', 'Conference Calendar', 'manage_options', 'tln-cc', 'tln_cc_settings_page' );
	}
);

add_action(
	'admin_post_tln_cc_refresh',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'tln-conference-calendar' ) );
		}
		check_admin_referer( 'tln_cc_refresh' );
		$ok = tln_cc_refresh_all( true );
		wp_safe_redirect( add_query_arg( 'tln_cc_refreshed', $ok ? '1' : '0', admin_url( 'options-general.php?page=tln-cc' ) ) );
		exit;
	}
);

function tln_cc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$data    = tln_cc_data();
	$page_id = (int) get_option( 'tln_cc_page_id' );
	echo '<div class="wrap"><h1>Conference Calendar</h1>';
	if ( isset( $_GET['tln_cc_refreshed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$ok = '1' === sanitize_text_field( wp_unslash( $_GET['tln_cc_refreshed'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? 'Calendar refreshed.' : 'Refresh failed; showing the last good copy.' ) . '</p></div>';
	}
	foreach ( array( 'dc' => 'D.C.', 'baltimore' => 'Baltimore' ) as $region => $name ) {
		$regional_data = 'dc' === $region ? $data : tln_cc_data( $region );
		$last         = (int) get_option( tln_cc_cache_key( 'tln_cc_last_fetch', $region ) );
		$error        = (string) get_option( tln_cc_cache_key( 'tln_cc_last_error', $region ), '' );
		echo '<p><strong>' . esc_html( $name ) . '</strong> &middot; Events: <strong>' . esc_html( $regional_data ? (string) count( $regional_data['events'] ) : '0' ) . '</strong>';
		echo ' &middot; Last fetched: <strong>' . esc_html( $last ? wp_date( 'M j, Y g:i a', $last ) : 'never' ) . '</strong>';
		if ( $error ) {
			echo ' &middot; Last error: <code>' . esc_html( $error ) . '</code>';
		}
		echo '</p>';
	}
	if ( $page_id && get_post( $page_id ) ) {
		echo '<p>Page: <a href="' . esc_url( get_edit_post_link( $page_id ) ) . '">' . esc_html( get_the_title( $page_id ) ) . '</a> (' . esc_html( get_post_status( $page_id ) ) . ')</p>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'tln_cc_refresh' );
	echo '<input type="hidden" name="action" value="tln_cc_refresh">';
	submit_button( 'Refresh now', 'secondary', 'submit', false );
	echo '</form>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'tln_cc' );
	echo '<table class="form-table"><tr><th scope="row"><label for="tln_cc_source_url">Calendar data URL</label></th><td>';
	echo '<input type="url" class="regular-text code" id="tln_cc_source_url" name="tln_cc_source_url" value="' . esc_attr( (string) get_option( 'tln_cc_source_url', '' ) ) . '" placeholder="' . esc_attr( TLN_CC_DEFAULT_SOURCE ) . '">';
		echo '<p class="description">Leave blank to use the default public feed.</p></td></tr></table>';
		echo '<table class="form-table"><tr><th scope="row"><label for="tln_cc_wall_hidden">Wall calendar: hide photo for</label></th><td>';
		echo '<input type="text" class="regular-text code" id="tln_cc_wall_hidden" name="tln_cc_wall_hidden" value="' . esc_attr( (string) get_option( 'tln_cc_wall_hidden', '' ) ) . '" placeholder="2027-05, 2027-06">';
		echo '<p class="description">Months (YYYY-MM, comma separated) whose photo and buy link are left off the wall calendar until you are ready to show them. Leave blank to show every photo.</p></td></tr></table>';
	echo '<table class="form-table"><tr><th scope="row">Coming up</th><td><fieldset>';
	echo '<label><input type="checkbox" name="tln_cc_coming_up_strip" value="yes"' . ( 'no' === get_option( 'tln_cc_coming_up_strip', 'yes' ) ? '' : ' checked' ) . '> Show the next three events in a strip under the site header</label><br>';
	echo '<label><input type="checkbox" name="tln_cc_coming_up_home" value="yes"' . ( 'no' === get_option( 'tln_cc_coming_up_home', 'yes' ) ? '' : ' checked' ) . '> Show a &ldquo;Coming up&rdquo; section with four events on the home page, above Issues</label>';
	echo '<p class="description">Both link to the calendar page. The strip is left off the calendar page, cart, checkout and account pages.</p></fieldset></td></tr></table>';
	submit_button();
	echo '</form>';
	echo '<h2>Shortcodes</h2><ul style="list-style:disc;padding-left:1.5em">';
	echo '<li><code>[tln_conferences]</code> full calendar with subscribe panel, topic filters and search</li>';
	echo '<li><code>[tln_conferences region="baltimore"]</code> fixed Baltimore calendar; otherwise use the city links or <code>?region=baltimore</code></li>';
	echo '<li><code>[tln_conferences theme="housing"]</code> one topic. Topics: ' . esc_html( $data ? implode( ', ', wp_list_pluck( $data['calendars'], 'slug' ) ) : '' ) . '</li>';
	echo '<li><code>[tln_conferences limit="5" compact="yes" subscribe="no"]</code> short list for a sidebar or the homepage</li>';
		echo '<li><code>[tln_conferences wall="no"]</code> full D.C. calendar without the wall calendar beside it</li>';
	echo '</ul></div>';
}

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=tln-cc' ) ) . '">Settings</a>' );
		return $links;
	}
);
