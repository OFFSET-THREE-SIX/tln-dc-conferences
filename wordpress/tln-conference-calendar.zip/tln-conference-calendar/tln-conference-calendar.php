<?php
/**
 * Plugin Name:       TLN Conference Calendar
 * Plugin URI:        https://thelocalnational.com/conferences/
 * Description:       The Local National's D.C. Conference Calendar. Add [tln_conferences] to any page for upcoming D.C. conferences with topic filters, calendar subscriptions and add-to-calendar links. Data comes from the public calendar feed and refreshes hourly.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            The Local National
 * License:           GPL-2.0-or-later
 * Text Domain:       tln-conference-calendar
 *
 * Shortcode options:
 *   [tln_conferences]                                   full calendar with subscribe panel and topic filters
 *   [tln_conferences theme="housing"]                   one topic (any calendar slug, e.g. transit, tln-picks, major)
 *   [tln_conferences limit="5" compact="yes" subscribe="no" filters="no"]   short list for a sidebar or the homepage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TLN_CC_VERSION', '1.0.0' );
define( 'TLN_CC_DEFAULT_SOURCE', 'https://offset-three-six.github.io/tln-dc-conferences/api/events.json' );
define( 'TLN_CC_PAGE_STATUS', 'draft' );
define( 'TLN_CC_FILE', __FILE__ );

/* ------------------------------------------------------------------ data */

function tln_cc_source_url() {
	$url = (string) get_option( 'tln_cc_source_url', '' );
	if ( '' === $url ) {
		$url = TLN_CC_DEFAULT_SOURCE;
	}
	return apply_filters( 'tln_cc_source_url', $url );
}

/** Fetch the public feed. Returns the decoded array, or null on any failure. */
function tln_cc_fetch() {
	$resp = wp_remote_get(
		tln_cc_source_url(),
		array(
			'timeout' => 10,
			'headers' => array( 'Accept' => 'application/json' ),
		)
	);
	if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
		update_option( 'tln_cc_last_error', is_wp_error( $resp ) ? $resp->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $resp ), false );
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( ! is_array( $data ) || ! isset( $data['events'], $data['calendars'] ) || ! is_array( $data['events'] ) || ! is_array( $data['calendars'] ) ) {
		update_option( 'tln_cc_last_error', 'Unexpected response format', false );
		return null;
	}
	set_transient( 'tln_cc_data', $data, 2 * HOUR_IN_SECONDS );
	update_option( 'tln_cc_last_good', $data, false );
	update_option( 'tln_cc_last_fetch', time(), false );
	delete_option( 'tln_cc_last_error' );
	return $data;
}

/** Cached data; falls back to the last good copy if the feed is unreachable. */
function tln_cc_data() {
	$data = get_transient( 'tln_cc_data' );
	if ( is_array( $data ) ) {
		return $data;
	}
	$data = tln_cc_fetch();
	if ( is_array( $data ) ) {
		return $data;
	}
	$stale = get_option( 'tln_cc_last_good' );
	if ( is_array( $stale ) ) {
		set_transient( 'tln_cc_data', $stale, 10 * MINUTE_IN_SECONDS );
		return $stale;
	}
	return null;
}

function tln_cc_today() {
	$now = new DateTime( 'now', new DateTimeZone( 'America/New_York' ) );
	return $now->format( 'Y-m-d' );
}

function tln_cc_str( $arr, $key ) {
	return ( is_array( $arr ) && isset( $arr[ $key ] ) && is_scalar( $arr[ $key ] ) ) ? (string) $arr[ $key ] : '';
}

function tln_cc_yes( $value ) {
	return in_array( strtolower( (string) $value ), array( 'yes', 'true', '1', 'on' ), true );
}

/* ------------------------------------------------------------------ assets */

add_action(
	'init',
	function () {
		$dir = plugin_dir_path( TLN_CC_FILE );
		$css = $dir . 'assets/tlncc.css';
		$js  = $dir . 'assets/tlncc.js';
		wp_register_style( 'tln-cc', plugins_url( 'assets/tlncc.css', TLN_CC_FILE ), array(), file_exists( $css ) ? (string) filemtime( $css ) : TLN_CC_VERSION );
		wp_register_script( 'tln-cc', plugins_url( 'assets/tlncc.js', TLN_CC_FILE ), array(), file_exists( $js ) ? (string) filemtime( $js ) : TLN_CC_VERSION, true );
		add_shortcode( 'tln_conferences', 'tln_cc_shortcode' );
	}
);

function tln_cc_page_has_shortcode() {
	if ( ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( $post->post_content, 'tln_conferences' );
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( tln_cc_page_has_shortcode() ) {
			wp_enqueue_style( 'tln-cc' );
		}
	}
);

/* Let browsers and calendar apps discover the feed on pages that show the calendar. */
add_action(
	'wp_head',
	function () {
		if ( ! tln_cc_page_has_shortcode() ) {
			return;
		}
		$data = tln_cc_data();
		if ( ! $data || empty( $data['calendars'][0]['links']['ics'] ) ) {
			return;
		}
		printf(
			'<link rel="alternate" type="text/calendar" title="%s" href="%s" />' . "\n",
			esc_attr( tln_cc_str( $data['calendars'][0], 'feed_name' ) ),
			esc_url( $data['calendars'][0]['links']['ics'] )
		);
	}
);

/* ------------------------------------------------------------------ rendering */

function tln_cc_shortcode( $atts ) {
	$a = shortcode_atts(
		array(
			'theme'     => 'all',
			'limit'     => 0,
			'subscribe' => 'yes',
			'filters'   => 'yes',
			'compact'   => 'no',
			'title'     => '',
		),
		$atts,
		'tln_conferences'
	);
	wp_enqueue_style( 'tln-cc' );
	wp_enqueue_script( 'tln-cc' );

	$data = tln_cc_data();
	if ( ! $data ) {
		return '<div class="tlncc"><p class="tlncc-empty">' . esc_html__( 'The conference calendar is updating. Please check back shortly.', 'tln-conference-calendar' ) . '</p></div>';
	}

	$today = tln_cc_today();
	$cals  = array();
	foreach ( $data['calendars'] as $c ) {
		if ( is_array( $c ) && isset( $c['slug'] ) ) {
			$cals[ (string) $c['slug'] ] = $c;
		}
	}
	$theme = sanitize_key( $a['theme'] );
	if ( ! isset( $cals[ $theme ] ) ) {
		$theme = 'all';
	}
	$limit     = absint( $a['limit'] );
	$compact   = tln_cc_yes( $a['compact'] );
	$subscribe = tln_cc_yes( $a['subscribe'] );
	$filters   = tln_cc_yes( $a['filters'] ) && 'all' === $theme && ! $compact;

	$upcoming = array();
	foreach ( $data['events'] as $e ) {
		if ( ! is_array( $e ) || tln_cc_str( $e, 'end_date' ) < $today || '' === tln_cc_str( $e, 'id' ) ) {
			continue;
		}
		$e['segments'] = ( isset( $e['segments'] ) && is_array( $e['segments'] ) ) ? array_map( 'strval', $e['segments'] ) : array();
		$upcoming[]    = $e;
	}
	$counts = array_fill_keys( array_keys( $cals ), 0 );
	foreach ( $upcoming as $e ) {
		$counts['all'] = isset( $counts['all'] ) ? $counts['all'] + 1 : 1;
		foreach ( $e['segments'] as $s ) {
			if ( isset( $counts[ $s ] ) ) {
				$counts[ $s ]++;
			}
		}
	}
	$events = array();
	foreach ( $upcoming as $e ) {
		if ( 'all' === $theme || in_array( $theme, $e['segments'], true ) ) {
			$events[] = $e;
		}
	}
	if ( $limit > 0 ) {
		$events = array_slice( $events, 0, $limit );
	}

	$out  = '<div class="tlncc' . ( $compact ? ' is-compact' : '' ) . '" data-tlncc data-default-seg="' . esc_attr( $filters ? 'all' : $theme ) . '">';
	if ( '' !== $a['title'] ) {
		$out .= '<h2 class="tlncc-h2">' . esc_html( $a['title'] ) . '</h2>';
	}
	if ( $subscribe ) {
		$out .= tln_cc_render_subscribe( $cals, $counts, $theme );
	}
	if ( $filters ) {
		$out .= tln_cc_render_tools( $cals, $counts );
	}
	$out .= '<div class="tlncc-list">';
	if ( ! $events ) {
		$out .= '<p class="tlncc-empty">' . esc_html__( 'No upcoming events are listed right now. Subscribe and new ones will appear as they are added.', 'tln-conference-calendar' ) . '</p>';
	}
	$group = null;
	foreach ( $events as $e ) {
		$label = tln_cc_group_label( $e, $today );
		if ( $label !== $group ) {
			if ( null !== $group ) {
				$out .= '</section>';
			}
			$out  .= '<section class="tlncc-month" data-tlncc-group><h3 class="tlncc-mh">' . esc_html( $label ) . '</h3>';
			$group = $label;
		}
		$out .= tln_cc_render_event( $e, $compact );
	}
	if ( null !== $group ) {
		$out .= '</section>';
	}
	$out .= '</div>';
	$out .= '<p class="tlncc-empty" data-tlncc-empty hidden>' . esc_html__( 'No events match. Try another topic or clear the search.', 'tln-conference-calendar' ) . '</p>';
	$out .= tln_cc_render_footer( $data, $theme, $compact );
	$out .= tln_cc_render_schema( $events );
	$out .= '</div>';
	return $out;
}

function tln_cc_group_label( $e, $today ) {
	$start = tln_cc_str( $e, 'start_date' );
	if ( $start < $today ) {
		return __( 'Under way', 'tln-conference-calendar' );
	}
	$d = DateTime::createFromFormat( '!Y-m-d', $start, new DateTimeZone( 'America/New_York' ) );
	return $d ? $d->format( 'F Y' ) : '';
}

function tln_cc_render_subscribe( $cals, $counts, $selected ) {
	if ( ! isset( $cals[ $selected ]['links'] ) ) {
		return '';
	}
	$opts  = '';
	$feeds = '';
	foreach ( $cals as $slug => $c ) {
		$l = isset( $c['links'] ) && is_array( $c['links'] ) ? $c['links'] : array();
		$n = isset( $counts[ $slug ] ) ? (int) $counts[ $slug ] : 0;
		/* translators: 1: calendar name, 2: number of upcoming events */
		$opts  .= sprintf(
			'<option value="%1$s" data-webcal="%2$s" data-google="%3$s" data-outlook="%4$s" data-office="%5$s" data-ics="%6$s"%7$s>%8$s</option>',
			esc_attr( $slug ),
			esc_url( tln_cc_str( $l, 'webcal' ) ),
			esc_url( tln_cc_str( $l, 'google' ) ),
			esc_url( tln_cc_str( $l, 'outlook' ) ),
			esc_url( tln_cc_str( $l, 'office' ) ),
			esc_url( tln_cc_str( $l, 'ics' ) ),
			selected( $slug, $selected, false ),
			esc_html( sprintf( '%s (%d upcoming)', tln_cc_str( $c, 'name' ), $n ) )
		);
		$feeds .= sprintf(
			'<li><strong>%1$s</strong><span>%2$s</span><a href="%3$s">Apple</a><a href="%4$s" target="_blank" rel="noopener">Google</a><a href="%5$s" target="_blank" rel="noopener">Outlook</a><a href="%6$s">.ics link</a></li>',
			esc_html( tln_cc_str( $c, 'name' ) ),
			esc_html( sprintf( '%d upcoming', $n ) ),
			esc_url( tln_cc_str( $l, 'webcal' ) ),
			esc_url( tln_cc_str( $l, 'google' ) ),
			esc_url( tln_cc_str( $l, 'outlook' ) ),
			esc_url( tln_cc_str( $l, 'ics' ) )
		);
	}
	$l   = $cals[ $selected ]['links'];
	$uid = 'tlncc-pick-' . wp_unique_id();
	$out  = '<section class="tlncc-sub" id="subscribe">';
	$out .= '<h2 class="tlncc-h2">' . esc_html__( 'Put it on your calendar', 'tln-conference-calendar' ) . '</h2>';
	$out .= '<p class="tlncc-note">' . esc_html__( 'Subscribe once and new events show up on their own. Take everything, or only the topics you follow.', 'tln-conference-calendar' ) . '</p>';
	$out .= '<div class="tlncc-sub-row"><label class="tlncc-label" for="' . esc_attr( $uid ) . '">' . esc_html__( 'Calendar', 'tln-conference-calendar' ) . '</label>';
	$out .= '<select class="tlncc-select" id="' . esc_attr( $uid ) . '" data-tlncc-sub>' . $opts . '</select></div>';
	$out .= '<div class="tlncc-sub-buttons">';
	$out .= '<a class="tlncc-btn" data-sub-k="webcal" href="' . esc_url( tln_cc_str( $l, 'webcal' ) ) . '">Apple Calendar</a>';
	$out .= '<a class="tlncc-btn" data-sub-k="google" href="' . esc_url( tln_cc_str( $l, 'google' ) ) . '" target="_blank" rel="noopener">Google Calendar</a>';
	$out .= '<a class="tlncc-btn" data-sub-k="outlook" href="' . esc_url( tln_cc_str( $l, 'outlook' ) ) . '" target="_blank" rel="noopener">Outlook.com</a>';
	$out .= '<a class="tlncc-btn is-ghost" data-sub-k="office" href="' . esc_url( tln_cc_str( $l, 'office' ) ) . '" target="_blank" rel="noopener">Outlook for work</a>';
	$out .= '<button type="button" class="tlncc-btn is-ghost tlncc-copy" data-sub-k="ics" data-url="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '">' . esc_html__( 'Copy feed link', 'tln-conference-calendar' ) . '</button>';
	$out .= '</div>';
	$out .= '<p class="tlncc-hint">' . esc_html__( 'On iPhone, iPad or Mac, tap Apple Calendar. Google subscriptions are added on the web and then sync to your phone. Any other calendar app can use the copied feed link.', 'tln-conference-calendar' ) . '</p>';
	/* translators: %d: number of calendar feeds */
	$out .= '<details class="tlncc-feeds"><summary>' . esc_html( sprintf( __( 'All %d calendar feeds', 'tln-conference-calendar' ), count( $cals ) ) ) . '</summary><ul>' . $feeds . '</ul></details>';
	$out .= '</section>';
	return $out;
}

function tln_cc_render_tools( $cals, $counts ) {
	$uid   = 'tlncc-q-' . wp_unique_id();
	$chips = sprintf(
		'<button type="button" class="tlncc-chip" data-seg="all" data-name="all topics" aria-pressed="true">%s<span>%d</span></button>',
		esc_html__( 'All', 'tln-conference-calendar' ),
		isset( $counts['all'] ) ? (int) $counts['all'] : 0
	);
	foreach ( $cals as $slug => $c ) {
		if ( 'all' === $slug || empty( $counts[ $slug ] ) ) {
			continue;
		}
		$chips .= sprintf(
			'<button type="button" class="tlncc-chip" data-seg="%1$s" data-name="%2$s" aria-pressed="false">%2$s<span>%3$d</span></button>',
			esc_attr( $slug ),
			esc_html( tln_cc_str( $c, 'name' ) ),
			(int) $counts[ $slug ]
		);
	}
	return '<div class="tlncc-tools"><div class="tlncc-filters" role="toolbar" aria-label="' . esc_attr__( 'Filter by topic', 'tln-conference-calendar' ) . '">' . $chips . '</div>'
		. '<div class="tlncc-search"><label class="tlncc-vh" for="' . esc_attr( $uid ) . '">' . esc_html__( 'Search events', 'tln-conference-calendar' ) . '</label>'
		. '<input id="' . esc_attr( $uid ) . '" type="search" placeholder="' . esc_attr__( 'Search events, organizers or venues', 'tln-conference-calendar' ) . '" data-tlncc-q autocomplete="off"></div></div>'
		. '<p class="tlncc-status" data-tlncc-status aria-live="polite"></p>';
}

function tln_cc_render_event( $e, $compact ) {
	$l     = ( isset( $e['links'] ) && is_array( $e['links'] ) ) ? $e['links'] : array();
	$names = ( isset( $e['segment_names'] ) && is_array( $e['segment_names'] ) ) ? $e['segment_names'] : array();
	$tags  = ! empty( $e['tln_pick'] ) ? '<span class="is-pick">' . esc_html__( 'TLN pick', 'tln-conference-calendar' ) . '</span>' : '';
	foreach ( $e['segments'] as $i => $slug ) {
		if ( 'tln-picks' !== $slug && isset( $names[ $i ] ) && is_scalar( $names[ $i ] ) ) {
			$tags .= '<span>' . esc_html( (string) $names[ $i ] ) . '</span>';
		}
	}
	$event_url = tln_cc_str( $e, 'event_url' );
	$reg_url   = tln_cc_str( $e, 'registration_url' );
	$title_url = $event_url ? $event_url : $reg_url;
	$title     = $title_url
		? '<a href="' . esc_url( $title_url ) . '" target="_blank" rel="noopener">' . esc_html( tln_cc_str( $e, 'title' ) ) . '</a>'
		: esc_html( tln_cc_str( $e, 'title' ) );
	$org_bits  = array_filter( array( tln_cc_str( $e, 'organizer' ), tln_cc_str( $e, 'format_label' ), tln_cc_str( $e, 'cost' ) ) );
	$text      = strtolower( implode( ' ', array( tln_cc_str( $e, 'title' ), tln_cc_str( $e, 'organizer' ), tln_cc_str( $e, 'location' ), tln_cc_str( $e, 'summary' ), implode( ' ', array_filter( $names, 'is_scalar' ) ) ) ) );
	$badge     = ( isset( $e['badge'] ) && is_array( $e['badge'] ) ) ? $e['badge'] : array();

	$out  = '<article class="tlncc-ev" id="e-' . esc_attr( tln_cc_str( $e, 'id' ) ) . '" data-segs="' . esc_attr( 'all ' . implode( ' ', $e['segments'] ) ) . '" data-text="' . esc_attr( $text ) . '">';
	$out .= '<div class="tlncc-badge" aria-hidden="true"><span class="m">' . esc_html( tln_cc_str( $badge, 'month' ) ) . '</span><span class="d">' . esc_html( tln_cc_str( $badge, 'day' ) ) . '</span>';
	if ( '' !== tln_cc_str( $badge, 'range' ) ) {
		$out .= '<span class="r">' . esc_html( tln_cc_str( $badge, 'range' ) ) . '</span>';
	}
	$out .= '</div><div class="tlncc-body">';
	if ( $tags && ! $compact ) {
		$out .= '<p class="tlncc-tags">' . $tags . '</p>';
	}
	$out .= '<h4 class="tlncc-title">' . $title . '</h4>';
	$out .= '<p class="tlncc-when">' . esc_html( tln_cc_str( $e, 'when' ) ) . '</p>';
	$out .= '<p class="tlncc-where">' . esc_html( tln_cc_str( $e, 'location' ) ) . '</p>';
	if ( $org_bits && ! $compact ) {
		$out .= '<p class="tlncc-org">' . esc_html( implode( ' · ', $org_bits ) ) . '</p>';
	}
	if ( '' !== tln_cc_str( $e, 'summary' ) && ! $compact ) {
		$out .= '<p class="tlncc-sum">' . esc_html( tln_cc_str( $e, 'summary' ) ) . '</p>';
	}
	$out .= '<div class="tlncc-actions"><details class="tlncc-add"><summary>' . esc_html__( 'Add to calendar', 'tln-conference-calendar' ) . '</summary><div class="tlncc-menu">';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'google' ) ) . '" target="_blank" rel="noopener">Google Calendar</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '">Apple Calendar (.ics)</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'outlook' ) ) . '" target="_blank" rel="noopener">Outlook.com</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'office' ) ) . '" target="_blank" rel="noopener">Outlook for work</a>';
	$out .= '<a href="' . esc_url( tln_cc_str( $l, 'ics' ) ) . '" download>' . esc_html__( 'Download .ics file', 'tln-conference-calendar' ) . '</a>';
	$out .= '</div></details>';
	if ( $event_url ) {
		$out .= '<a class="tlncc-link" href="' . esc_url( $event_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Event page', 'tln-conference-calendar' ) . '</a>';
	}
	if ( $reg_url && ! $compact ) {
		$out .= '<a class="tlncc-link" href="' . esc_url( $reg_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Register', 'tln-conference-calendar' ) . '</a>';
	}
	$out .= '</div></div></article>';
	return $out;
}

function tln_cc_render_footer( $data, $theme, $compact ) {
	$base    = untrailingslashit( tln_cc_str( $data, 'base_url' ) );
	$submit  = tln_cc_str( $data, 'submit_url' );
	$page_id = (int) get_option( 'tln_cc_page_id' );
	$full    = $page_id ? get_permalink( $page_id ) : tln_cc_str( $data, 'page_url' );
	$out     = '<footer class="tlncc-foot">';
	if ( $compact && $full ) {
		$out .= '<a href="' . esc_url( 'all' === $theme ? $full : add_query_arg( 'theme', $theme, $full ) ) . '">' . esc_html__( 'See the full calendar', 'tln-conference-calendar' ) . '</a>';
	} else {
		/* translators: %s: date the calendar was last updated */
		$out .= esc_html( sprintf( __( 'Updated %s.', 'tln-conference-calendar' ), tln_cc_str( $data, 'updated_label' ) ) ) . ' ';
		if ( $submit ) {
			$out .= '<a href="' . esc_url( $submit ) . '" target="_blank" rel="noopener">' . esc_html__( 'Suggest an event', 'tln-conference-calendar' ) . '</a> · ';
		}
		if ( $base ) {
			$out .= '<a href="' . esc_url( $base . '/api/events.json' ) . '">JSON</a> · <a href="' . esc_url( $base . '/api/events.csv' ) . '">CSV</a> · ';
		}
		$out .= esc_html( tln_cc_str( $data, 'note' ) );
	}
	return $out . '</footer>';
}

/* schema.org Event markup so search engines can show these as events. */
function tln_cc_render_schema( $events ) {
	$graph = array();
	foreach ( array_slice( $events, 0, 100 ) as $e ) {
		if ( isset( $e['schema'] ) && is_array( $e['schema'] ) ) {
			$graph[] = $e['schema'];
		}
	}
	if ( ! $graph ) {
		return '';
	}
	$json = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
	);
	return $json ? '<script type="application/ld+json">' . $json . '</script>' : '';
}

/* ------------------------------------------------------------------ refresh schedule */

add_action( 'tln_cc_refresh', 'tln_cc_fetch' );

register_activation_hook( __FILE__, 'tln_cc_activate' );
function tln_cc_activate() {
	if ( ! wp_next_scheduled( 'tln_cc_refresh' ) ) {
		wp_schedule_event( time() + 60, 'hourly', 'tln_cc_refresh' );
	}
	tln_cc_fetch();
	tln_cc_create_page();
}

register_deactivation_hook( __FILE__, 'tln_cc_deactivate' );
function tln_cc_deactivate() {
	wp_clear_scheduled_hook( 'tln_cc_refresh' );
}

/* Creates the calendar page once (at /conferences/), as a draft unless the build says publish. */
function tln_cc_create_page() {
	$existing_id = (int) get_option( 'tln_cc_page_id' );
	if ( $existing_id && get_post( $existing_id ) ) {
		return $existing_id;
	}
	$existing = get_page_by_path( 'conferences', OBJECT, 'page' );
	if ( $existing ) {
		update_option( 'tln_cc_page_id', (int) $existing->ID, false );
		return (int) $existing->ID;
	}
	$author = get_current_user_id();
	if ( ! $author ) {
		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		$author = $admins ? (int) $admins[0] : 0;
	}
	$status  = in_array( TLN_CC_PAGE_STATUS, array( 'publish', 'draft' ), true ) ? TLN_CC_PAGE_STATUS : 'draft';
	$intro   = 'Conferences, summits and public forums in Washington, D.C. that show where national issues are headed. Subscribe to the whole calendar or only the topics you follow, or add single events to your own calendar. Updated every morning.';
	$content = "<!-- wp:paragraph -->\n<p>" . esc_html( $intro ) . "</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[tln_conferences]\n<!-- /wp:shortcode -->";
	$id      = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => $status,
			'post_title'   => 'D.C. Conference Calendar',
			'post_name'    => 'conferences',
			'post_content' => $content,
			'post_excerpt' => $intro,
			'post_author'  => $author,
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_option( 'tln_cc_page_id', (int) $id, false );
	return (int) $id;
}

/* ------------------------------------------------------------------ settings */

add_action(
	'admin_init',
	function () {
		register_setting(
			'tln_cc',
			'tln_cc_source_url',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => '',
			)
		);
	}
);

add_action(
	'admin_menu',
	function () {
		add_options_page( 'Conference Calendar', 'Conference Calendar', 'manage_options', 'tln-cc', 'tln_cc_settings_page' );
	}
);

add_action(
	'admin_post_tln_cc_refresh',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'tln-conference-calendar' ) );
		}
		check_admin_referer( 'tln_cc_refresh' );
		delete_transient( 'tln_cc_data' );
		$ok = tln_cc_fetch();
		wp_safe_redirect( add_query_arg( 'tln_cc_refreshed', $ok ? '1' : '0', admin_url( 'options-general.php?page=tln-cc' ) ) );
		exit;
	}
);

function tln_cc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$data    = tln_cc_data();
	$last    = (int) get_option( 'tln_cc_last_fetch' );
	$error   = (string) get_option( 'tln_cc_last_error', '' );
	$page_id = (int) get_option( 'tln_cc_page_id' );
	echo '<div class="wrap"><h1>Conference Calendar</h1>';
	if ( isset( $_GET['tln_cc_refreshed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$ok = '1' === sanitize_text_field( wp_unslash( $_GET['tln_cc_refreshed'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? 'Calendar refreshed.' : 'Refresh failed; showing the last good copy.' ) . '</p></div>';
	}
	echo '<p>Events: <strong>' . esc_html( $data ? (string) count( $data['events'] ) : '0' ) . '</strong>';
	echo ' &middot; Last fetched: <strong>' . esc_html( $last ? wp_date( 'M j, Y g:i a', $last ) : 'never' ) . '</strong>';
	if ( $error ) {
		echo ' &middot; Last error: <code>' . esc_html( $error ) . '</code>';
	}
	if ( $page_id && get_post( $page_id ) ) {
		echo ' &middot; Page: <a href="' . esc_url( get_edit_post_link( $page_id ) ) . '">' . esc_html( get_the_title( $page_id ) ) . '</a> (' . esc_html( get_post_status( $page_id ) ) . ')';
	}
	echo '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'tln_cc_refresh' );
	echo '<input type="hidden" name="action" value="tln_cc_refresh">';
	submit_button( 'Refresh now', 'secondary', 'submit', false );
	echo '</form>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'tln_cc' );
	echo '<table class="form-table"><tr><th scope="row"><label for="tln_cc_source_url">Calendar data URL</label></th><td>';
	echo '<input type="url" class="regular-text code" id="tln_cc_source_url" name="tln_cc_source_url" value="' . esc_attr( (string) get_option( 'tln_cc_source_url', '' ) ) . '" placeholder="' . esc_attr( TLN_CC_DEFAULT_SOURCE ) . '">';
	echo '<p class="description">Leave blank to use the default public feed.</p></td></tr></table>';
	submit_button();
	echo '</form>';
	echo '<h2>Shortcodes</h2><ul style="list-style:disc;padding-left:1.5em">';
	echo '<li><code>[tln_conferences]</code> full calendar with subscribe panel, topic filters and search</li>';
	echo '<li><code>[tln_conferences theme="housing"]</code> one topic. Topics: ' . esc_html( $data ? implode( ', ', wp_list_pluck( $data['calendars'], 'slug' ) ) : '' ) . '</li>';
	echo '<li><code>[tln_conferences limit="5" compact="yes" subscribe="no"]</code> short list for a sidebar or the homepage</li>';
	echo '</ul></div>';
}

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=tln-cc' ) ) . '">Settings</a>' );
		return $links;
	}
);
