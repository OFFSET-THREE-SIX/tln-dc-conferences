<?php
/**
 * Removes the TLN Conference Calendar settings and cache. The calendar page itself is kept.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_transient( 'tln_cc_data' );
delete_transient( 'tln_cc_data_baltimore' );
foreach ( array( 'tln_cc_source_url', 'tln_cc_wall_hidden', 'tln_cc_coming_up_strip', 'tln_cc_coming_up_home', 'tln_cc_last_good', 'tln_cc_last_fetch', 'tln_cc_last_error', 'tln_cc_page_id', 'tln_cc_last_good_baltimore', 'tln_cc_last_fetch_baltimore', 'tln_cc_last_error_baltimore' ) as $tln_cc_option ) {
	delete_option( $tln_cc_option );
}
wp_clear_scheduled_hook( 'tln_cc_refresh' );
