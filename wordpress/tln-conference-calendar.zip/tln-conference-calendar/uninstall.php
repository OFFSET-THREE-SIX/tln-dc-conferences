<?php
/**
 * Removes the TLN Conference Calendar settings and cache. The calendar page itself is kept.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_transient( 'tln_cc_data' );
foreach ( array( 'tln_cc_source_url', 'tln_cc_last_good', 'tln_cc_last_fetch', 'tln_cc_last_error', 'tln_cc_page_id' ) as $tln_cc_option ) {
	delete_option( $tln_cc_option );
}
wp_clear_scheduled_hook( 'tln_cc_refresh' );
