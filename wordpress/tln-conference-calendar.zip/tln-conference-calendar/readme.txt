=== TLN Conference Calendar ===
Contributors: thelocalnational
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

The Local National's D.C. Conference Calendar, rendered natively on the site.

== Description ==

Add `[tln_conferences]` to any page to show upcoming conferences, summits and public forums in Washington, D.C. Readers can:

* subscribe to the whole calendar, or to one topic (housing, schools, transit and more), in Apple, Google or Outlook Calendar;
* add a single event to their calendar;
* filter by topic and search.

The plugin reads the public calendar feed (JSON) and caches it for up to two hours, refreshing hourly in the background. If the feed is unreachable, it keeps showing the last good copy. Each event is also marked up as a schema.org Event for search engines.

On activation it creates a "D.C. Conference Calendar" page at /conferences/ (unless that page already exists).

== Shortcode options ==

* `[tln_conferences]` full calendar
* `[tln_conferences theme="housing"]` one topic. Use any calendar slug: tln-picks, major, housing, schools, home-rule, federal-workforce, public-safety, transit, health, economy, governance
* `[tln_conferences limit="5" compact="yes" subscribe="no"]` short list for a sidebar or the homepage
* `title="..."` adds a heading

Settings > Conference Calendar shows the last refresh time and has a "Refresh now" button.
