=== TLN Conference Calendar ===
Contributors: thelocalnational
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later

The Local National's D.C. and optional Baltimore Conference Calendars, rendered natively on the site.

== Description ==

Add `[tln_conferences]` to any page to show upcoming conferences, summits and public forums in Washington, D.C. D.C. remains the default. A city switch above the full calendar lets readers choose Baltimore on the same page at `?region=baltimore`. Readers can:

* subscribe to the whole calendar, or to one topic (housing, schools, transit and more), in Apple, Google or Outlook Calendar;
* add a single event to their calendar;
* filter by topic and search.

The full D.C. calendar also shows a wall calendar beside the list: a photo of the month from the shop's 2027 prints, a month grid with a dot for each event, circled TLN picks, month paging and a panel that lists the events on the day you tap. The wall follows the topic and search filters. A "Buy this print" link appears under each photo once that print is published and the shop is out of coming-soon mode. Months listed under Settings > Conference Calendar > "Wall calendar: hide photo for" show a plain masthead header instead of a photo, with no buy link.

The plugin reads the public calendar feeds (JSON) and caches each city separately for up to two hours, refreshing both hourly in the background. If a feed is unreachable, it keeps showing that city's last good copy, never another city's events. If Baltimore has no saved copy, a friendly message links back to D.C. Each event is also marked up as a schema.org Event for search engines.

Baltimore data comes from baltimore.json in the same directory as the configured D.C. source. Calendar subscriptions and API links use the URLs supplied by the selected city's JSON. Older D.C. JSON without region or API metadata remains supported.

On activation it creates a "D.C. Conference Calendar" page at /conferences/ (unless that page already exists).

== Shortcode options ==

* `[tln_conferences]` full calendar, defaulting to D.C., with a city switch
* `[tln_conferences region="baltimore"]` fixed Baltimore calendar; hides the city switch and ignores the region query parameter
* `[tln_conferences region="dc"]` fixed D.C. calendar; also hides the city switch
* `[tln_conferences theme="housing"]` one topic. Use any calendar slug: tln-picks, major, housing, schools, home-rule, federal-workforce, public-safety, transit, health, economy, governance
* `[tln_conferences region="baltimore" theme="housing"]` one Baltimore topic
* `[tln_conferences limit="5" compact="yes" subscribe="no"]` short list for a sidebar or the homepage, without a city switch; follows the region query unless pinned
* `title="..."` adds a heading
* `[tln_conferences wall="no"]` full D.C. calendar without the wall calendar (the wall never appears on Baltimore, topic, limited or compact lists)

Without a valid fixed region attribute, only `?region=baltimore` selects Baltimore; absent or unknown region values select D.C. The D.C. city link does not include a region query parameter. Topic links such as `?region=baltimore&theme=housing` work with the existing JavaScript filters. City links use the current page permalink and reset request-only topic filters.

Settings > Conference Calendar shows the event count, last refresh time and last error for each city and has a "Refresh now" button that clears both transient caches and fetches both feeds, retaining each last-good copy on failure.

== Changelog ==
= 1.2.0 =
* Add the wall calendar beside the full D.C. calendar: monthly photo from the shop prints, month grid with event dots and TLN-pick circles, month paging, a day panel, and filter and search sync.
* Add the "Buy this print" link, shown only when the print is published and the shop is no longer in coming-soon mode.
* Add the "hide photo for" month list so individual photos can be held back, plus the `wall="no"` shortcode option.

= 1.1.0 =
* Add the optional Baltimore calendar, server-rendered city switch and fixed region shortcodes.
* Isolate per-city caches and refresh both feeds on activation, hourly and manually.
* Use region-specific subscriptions, discovery links, API links and compact-list destinations.
* Preserve region query parameters during topic filtering and validate URL topics before building selectors.
* Keep the default D.C. calendar and legacy JSON support.

= 1.0.0 =
* Initial native D.C. calendar with topic filters, subscriptions, event links and hourly caching.
